# PLP Python Week 8 - My Python Toolkit

## What this toolkit does
This is a menu-driven Python program with three tools:
1. **Number Guessing Game** - guess a randomly selected number from 1 to 10 and receive hints.
2. **To-Do List** - add, view, and remove tasks during the program run.
3. **Simple Calculator** - add, subtract, multiply, or divide two numbers.

The main menu repeats until the user chooses Quit. Invalid menu choices are handled with a friendly message.

## Files
- `toolkit_plan.txt` - the plan and exact menu text.
- `toolkit.py` - the complete Python program.
- `screenshots/` - add your screenshots of the menu, invalid choice, and each tool running.

## How to run
1. Open this repository in GitHub Codespaces or another Python environment.
2. Open the terminal.
3. Run:

   ```bash
   python toolkit.py
   ```

   If your environment uses `python3`, run `python3 toolkit.py`.

## Testing checklist
- [ ] Main menu appears.
- [ ] Invalid menu choice displays a polite message and returns to the menu.
- [ ] Number guessing game works, including incorrect guesses.
- [ ] To-do list can add, display, and remove tasks.
- [ ] Calculator performs the four operations.
- [ ] Calculator handles division by zero and invalid number input.
- [ ] Quit displays the goodbye message.

## Reflection (edit this after testing)
The hardest part of this project was making the menu return after each tool without ending the whole program. The bug that took the longest to fix was handling invalid input without crashing or getting stuck. I learned how to use functions to organize a program into smaller tools. I also practiced loops, conditionals, lists, and f-strings. The to-do list helped me understand how a list can change while a program is running. I tested the tools from the menu and checked that invalid choices were handled politely. If I had one more week, I would add a countdown timer and save the to-do list to a file so tasks remain available after the program closes.

**Important:** Update the reflection so it accurately describes your own experience and the bug you actually found and fixed.
